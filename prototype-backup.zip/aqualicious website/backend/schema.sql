-- =============================================================
-- AquaLicious Water Refilling Station – Database Schema
-- Engine: MySQL 8.0+
-- Run: mysql -u root -p < schema.sql
-- =============================================================

CREATE DATABASE IF NOT EXISTS aqualicious_db
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE aqualicious_db;

-- ── USERS ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(120)        NOT NULL,
    username   VARCHAR(60)  UNIQUE NOT NULL,
    password   VARCHAR(255)        NOT NULL,  -- bcrypt hash
    role       ENUM('admin','staff') DEFAULT 'admin',
    created_at TIMESTAMP           DEFAULT CURRENT_TIMESTAMP
);

-- Seed default admin (password: admin123)
INSERT IGNORE INTO users (name, username, password, role) VALUES
('Administrator', 'admin', '$2y$12$KIXqS5XVAQXkH9Ua3qPGBuFMLzGp4Oa0dNFV0rM1kHBLxmKl7M2Sq', 'admin');

-- ── CATEGORIES ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
    id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) UNIQUE NOT NULL
);

INSERT IGNORE INTO categories (name) VALUES
('Slim'),('Round'),('Purified'),('Mineral'),('Other');

-- ── PRODUCTS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS products (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(160)   NOT NULL,
    category_id INT UNSIGNED   NOT NULL,
    selling_price   DECIMAL(10,2)  NOT NULL,
    production_cost DECIMAL(10,2)  NOT NULL DEFAULT 0,
    stock       INT            NOT NULL DEFAULT 0,
    reorder_pt  INT            NOT NULL DEFAULT 0,
    active      TINYINT(1)     NOT NULL DEFAULT 1,
    created_at  TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Seed sample products
INSERT IGNORE INTO products (name, category_id, selling_price, production_cost, stock, reorder_pt) VALUES
('Slim Bottle 500ml',  1, 8,  3,  120, 30),
('Round Bottle 500ml', 2, 8,  3,  95,  30),
('Slim Gallon 5L',     1, 25, 10, 60,  20),
('Round Gallon 5L',    2, 25, 10, 14,  20),
('Purified Water 1L',  3, 12, 4,  200, 50),
('Mineral Water 1.5L', 4, 18, 7,  5,   25);

-- ── SALES ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sales (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    product_id  INT UNSIGNED   NOT NULL,
    qty         INT            NOT NULL,
    unit_price  DECIMAL(10,2)  NOT NULL,
    total       DECIMAL(10,2)  NOT NULL,
    customer    VARCHAR(120)   DEFAULT 'Walk-in',
    status      ENUM('Completed','Void') DEFAULT 'Completed',
    sold_at     DATETIME       DEFAULT CURRENT_TIMESTAMP,
    created_by  INT UNSIGNED,
    FOREIGN KEY (product_id)  REFERENCES products(id),
    FOREIGN KEY (created_by)  REFERENCES users(id)
);

-- ── INVENTORY LOGS ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS inventory_logs (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    product_id INT UNSIGNED NOT NULL,
    change_qty INT          NOT NULL,          -- +restock / -sale
    reason     VARCHAR(120) DEFAULT 'Manual',
    logged_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    logged_by  INT UNSIGNED,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (logged_by)  REFERENCES users(id)
);

-- ── VIEWS ─────────────────────────────────────────────────────
CREATE OR REPLACE VIEW v_sales_summary AS
    SELECT
        DATE(s.sold_at)     AS sale_date,
        COUNT(*)            AS transactions,
        SUM(s.qty)          AS units_sold,
        SUM(s.total)        AS revenue,
        SUM((s.unit_price - p.production_cost) * s.qty) AS gross_profit
    FROM sales s
    JOIN products p ON p.id = s.product_id
    WHERE s.status = 'Completed'
    GROUP BY DATE(s.sold_at);

CREATE OR REPLACE VIEW v_rop_alerts AS
    SELECT id, name, stock, reorder_pt,
           (stock - reorder_pt) AS stock_above_rop
    FROM products
    WHERE stock <= reorder_pt AND active = 1
    ORDER BY stock_above_rop ASC;
