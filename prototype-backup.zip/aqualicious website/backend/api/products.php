<?php
// backend/api/products.php  –  CRUD for products
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../config/db.php';

setCORSHeaders();
requireAuth();

$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);

// ── LIST / GET ───────────────────────────────────────────────────
if ($method === 'GET') {
    $db = getDB();
    if ($id) {
        $stmt = $db->prepare('
            SELECT p.*, c.name AS category
            FROM products p JOIN categories c ON c.id = p.category_id
            WHERE p.id = ? AND p.active = 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        $row ? jsonSuccess($row) : jsonError('Product not found.', 404);
    }
    $search = $_GET['search'] ?? '';
    $cat    = $_GET['category'] ?? '';
    $sql    = 'SELECT p.*, c.name AS category FROM products p JOIN categories c ON c.id = p.category_id WHERE p.active = 1';
    $params = [];
    if ($search) { $sql .= ' AND p.name LIKE ?'; $params[] = "%$search%"; }
    if ($cat)    { $sql .= ' AND c.name = ?';    $params[] = $cat; }
    $sql .= ' ORDER BY p.name ASC';
    $stmt = $db->prepare($sql); $stmt->execute($params);
    jsonSuccess($stmt->fetchAll());
}

// ── CREATE ────────────────────────────────────────────────────────
if ($method === 'POST') {
    $body = getJsonBody();
    $name     = trim($body['name']     ?? '');
    $category = trim($body['category'] ?? '');
    $price    = (float)($body['price']    ?? 0);
    $cost     = (float)($body['cost']     ?? 0);
    $stock    = (int)  ($body['stock']    ?? 0);
    $reorder  = (int)  ($body['reorder']  ?? 0);
    if (!$name || !$category || $price <= 0) jsonError('name, category, and price are required.');

    $db = getDB();
    $catRow = $db->prepare('SELECT id FROM categories WHERE name = ?');
    $catRow->execute([$category]);
    $cat = $catRow->fetch();
    if (!$cat) {
        $db->prepare('INSERT INTO categories (name) VALUES (?)')->execute([$category]);
        $catId = (int)$db->lastInsertId();
    } else {
        $catId = (int)$cat['id'];
    }

    $ins = $db->prepare('INSERT INTO products (name,category_id,selling_price,production_cost,stock,reorder_pt) VALUES (?,?,?,?,?,?)');
    $ins->execute([$name,$catId,$price,$cost,$stock,$reorder]);
    jsonSuccess(['id' => (int)$db->lastInsertId()], 'Product created.');
}

// ── UPDATE ────────────────────────────────────────────────────────
if ($method === 'PUT') {
    if (!$id) jsonError('id required.');
    $body    = getJsonBody();
    $db      = getDB();
    $catRow  = $db->prepare('SELECT id FROM categories WHERE name = ?');
    $catRow->execute([trim($body['category']??'')]);
    $cat = $catRow->fetch();
    $catId = $cat ? (int)$cat['id'] : null;
    if (!$catId) jsonError('Category not found.');

    $upd = $db->prepare('
        UPDATE products SET name=?,category_id=?,selling_price=?,production_cost=?,stock=?,reorder_pt=?
        WHERE id=? AND active=1');
    $upd->execute([
        trim($body['name']??''), $catId,
        (float)($body['price']??0),(float)($body['cost']??0),
        (int)($body['stock']??0),(int)($body['reorder']??0),
        $id
    ]);
    $upd->rowCount() ? jsonSuccess(null,'Product updated.') : jsonError('Product not found.',404);
}

// ── DELETE (soft) ─────────────────────────────────────────────────
if ($method === 'DELETE') {
    if (!$id) jsonError('id required.');
    $del = getDB()->prepare('UPDATE products SET active=0 WHERE id=?');
    $del->execute([$id]);
    $del->rowCount() ? jsonSuccess(null,'Product deleted.') : jsonError('Product not found.',404);
}
