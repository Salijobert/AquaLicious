<?php
// backend/api/inventory.php  –  Stock levels, ROP alerts, restock
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../config/db.php';

setCORSHeaders();
$user = requireAuth();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'list';

switch ($action) {

    // ── STOCK LIST ────────────────────────────────────────────────
    case 'list':
        $db   = getDB();
        $stmt = $db->query('
            SELECT p.id, p.name, p.stock, p.reorder_pt,
                   c.name AS category,
                   (p.stock <= p.reorder_pt) AS is_low
            FROM products p JOIN categories c ON c.id = p.category_id
            WHERE p.active = 1 ORDER BY p.name');
        jsonSuccess($stmt->fetchAll());
        break;

    // ── ROP ALERTS ────────────────────────────────────────────────
    case 'rop':
        $stmt = getDB()->query('SELECT * FROM v_rop_alerts');
        jsonSuccess($stmt->fetchAll());
        break;

    // ── UPDATE STOCK (quick set) ──────────────────────────────────
    case 'set':
        if ($method !== 'POST') jsonError('POST required.', 405);
        $body  = getJsonBody();
        $pid   = (int)  ($body['product_id'] ?? 0);
        $stock = (int)  ($body['stock']      ?? -1);
        if (!$pid || $stock < 0) jsonError('product_id and stock required.');

        $db   = getDB();
        $cur  = $db->prepare('SELECT stock FROM products WHERE id=? AND active=1');
        $cur->execute([$pid]); $row = $cur->fetch();
        if (!$row) jsonError('Product not found.',404);

        $diff = $stock - $row['stock'];
        $db->prepare('UPDATE products SET stock=? WHERE id=?')->execute([$stock,$pid]);
        $db->prepare('INSERT INTO inventory_logs (product_id,change_qty,reason,logged_by) VALUES (?,?,?,?)')
           ->execute([$pid,$diff,'Manual stock update',$user['id']]);
        jsonSuccess(null,'Stock updated.');
        break;

    // ── RESTOCK (add qty) ─────────────────────────────────────────
    case 'restock':
        if ($method !== 'POST') jsonError('POST required.', 405);
        $body = getJsonBody();
        $pid  = (int)($body['product_id'] ?? 0);
        $qty  = (int)($body['qty']        ?? 0);
        if (!$pid || $qty < 1) jsonError('product_id and qty >= 1 required.');

        $db = getDB();
        $db->prepare('UPDATE products SET stock = stock + ? WHERE id=? AND active=1')->execute([$qty,$pid]);
        $db->prepare('INSERT INTO inventory_logs (product_id,change_qty,reason,logged_by) VALUES (?,?,?,?)')
           ->execute([$pid,$qty,'Restock',$user['id']]);
        jsonSuccess(null, 'Restocked successfully.');
        break;

    // ── INVENTORY LOG ─────────────────────────────────────────────
    case 'logs':
        $pid  = (int)($_GET['product_id'] ?? 0);
        $sql  = 'SELECT il.*, p.name AS product_name FROM inventory_logs il JOIN products p ON p.id=il.product_id';
        $params = [];
        if ($pid) { $sql .= ' WHERE il.product_id=?'; $params[]=$pid; }
        $sql .= ' ORDER BY il.logged_at DESC LIMIT 100';
        $stmt = getDB()->prepare($sql); $stmt->execute($params);
        jsonSuccess($stmt->fetchAll());
        break;

    default:
        jsonError('Unknown action.', 404);
}
