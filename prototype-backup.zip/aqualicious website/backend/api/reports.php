<?php
// backend/api/reports.php  –  Data analytics & summary reports
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../config/db.php';

setCORSHeaders();
requireAuth();

$action = $_GET['action'] ?? 'summary';
$from   = $_GET['from']   ?? date('Y-m-d', strtotime('-30 days'));
$to     = $_GET['to']     ?? date('Y-m-d');

$db = getDB();

switch ($action) {

    // ── SUMMARY ───────────────────────────────────────────────────
    case 'summary':
        $stmt = $db->prepare('
            SELECT
                COUNT(*) AS transactions,
                SUM(s.qty) AS units_sold,
                SUM(s.total) AS revenue,
                SUM((s.unit_price - p.production_cost) * s.qty) AS gross_profit,
                AVG(s.total) AS avg_sale
            FROM sales s JOIN products p ON p.id=s.product_id
            WHERE s.status="Completed" AND DATE(s.sold_at) BETWEEN ? AND ?');
        $stmt->execute([$from,$to]);
        jsonSuccess($stmt->fetch());
        break;

    // ── MONTHLY REVENUE ───────────────────────────────────────────
    case 'monthly':
        $stmt = $db->query('
            SELECT DATE_FORMAT(sold_at, "%Y-%m") AS month,
                   COUNT(*) AS transactions,
                   SUM(qty) AS units_sold,
                   SUM(total) AS revenue
            FROM sales
            WHERE status="Completed"
            GROUP BY DATE_FORMAT(sold_at, "%Y-%m") ORDER BY month DESC');
        jsonSuccess($stmt->fetchAll());
        break;

    // ── DAILY TREND ───────────────────────────────────────────────
    case 'daily':
        $stmt = $db->prepare('
            SELECT DATE(sold_at) AS day,
                   COUNT(*) AS transactions,
                   SUM(qty) AS units_sold,
                   SUM(total) AS revenue
            FROM sales
            WHERE status="Completed" AND DATE(sold_at) BETWEEN ? AND ?
            GROUP BY DATE(sold_at) ORDER BY day ASC');
        $stmt->execute([$from,$to]);
        jsonSuccess($stmt->fetchAll());
        break;

    // ── TOP PRODUCTS ──────────────────────────────────────────────
    case 'top_products':
        $limit = (int)($_GET['limit'] ?? 10);
        $stmt  = $db->prepare('
            SELECT p.id, p.name, c.name AS category,
                   SUM(s.qty) AS units_sold,
                   SUM(s.total) AS revenue,
                   SUM((s.unit_price - p.production_cost)*s.qty) AS profit
            FROM sales s
            JOIN products p ON p.id=s.product_id
            JOIN categories c ON c.id=p.category_id
            WHERE s.status="Completed" AND DATE(s.sold_at) BETWEEN ? AND ?
            GROUP BY p.id ORDER BY revenue DESC LIMIT ?');
        $stmt->execute([$from,$to,$limit]);
        jsonSuccess($stmt->fetchAll());
        break;

    // ── CATEGORY BREAKDOWN ────────────────────────────────────────
    case 'categories':
        $stmt = $db->prepare('
            SELECT c.name AS category,
                   SUM(s.qty) AS units_sold,
                   SUM(s.total) AS revenue
            FROM sales s
            JOIN products p ON p.id=s.product_id
            JOIN categories c ON c.id=p.category_id
            WHERE s.status="Completed" AND DATE(s.sold_at) BETWEEN ? AND ?
            GROUP BY c.id ORDER BY revenue DESC');
        $stmt->execute([$from,$to]);
        jsonSuccess($stmt->fetchAll());
        break;

    // ── PEAK DAYS-OF-WEEK ─────────────────────────────────────────
    case 'peak_days':
        $stmt = $db->prepare('
            SELECT DAYNAME(sold_at) AS day_name,
                   DAYOFWEEK(sold_at) AS dow,
                   COUNT(*) AS transactions,
                   SUM(total) AS revenue
            FROM sales
            WHERE status="Completed" AND DATE(sold_at) BETWEEN ? AND ?
            GROUP BY DAYOFWEEK(sold_at), DAYNAME(sold_at)
            ORDER BY dow');
        $stmt->execute([$from,$to]);
        jsonSuccess($stmt->fetchAll());
        break;

    default:
        jsonError('Unknown report action.', 404);
}
