<?php
// backend/api/auth.php  –  Login / Logout / Register
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../config/db.php';

setCORSHeaders();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($action) {

    // ── LOGIN ────────────────────────────────────────────────────
    case 'login':
        if ($method !== 'POST') jsonError('POST required', 405);
        $body = getJsonBody();
        $username = trim($body['username'] ?? '');
        $password = $body['password'] ?? '';
        if (!$username || !$password) jsonError('Username and password required.');

        $stmt = getDB()->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password'])) {
            jsonError('Invalid credentials.', 401);
        }

        session_start();
        $_SESSION['user'] = ['id' => $user['id'], 'name' => $user['name'], 'role' => $user['role']];
        unset($user['password']);
        jsonSuccess($user, 'Login successful.');
        break;

    // ── LOGOUT ───────────────────────────────────────────────────
    case 'logout':
        session_start();
        session_destroy();
        jsonSuccess(null, 'Logged out.');
        break;

    // ── REGISTER ─────────────────────────────────────────────────
    case 'register':
        if ($method !== 'POST') jsonError('POST required', 405);
        $body = getJsonBody();
        $name     = trim($body['name']     ?? '');
        $username = trim($body['username'] ?? '');
        $password = $body['password']      ?? '';
        if (!$name || !$username || !$password) jsonError('All fields required.');
        if (strlen($password) < 6) jsonError('Password must be at least 6 characters.');

        $db = getDB();
        $chk = $db->prepare('SELECT id FROM users WHERE username = ?');
        $chk->execute([$username]);
        if ($chk->fetch()) jsonError('Username already taken.');

        $hash = password_hash($password, PASSWORD_BCRYPT);
        $ins  = $db->prepare('INSERT INTO users (name, username, password) VALUES (?,?,?)');
        $ins->execute([$name, $username, $hash]);
        jsonSuccess(['id' => $db->lastInsertId()], 'Account created.');
        break;

    default:
        jsonError('Unknown action.', 404);
}
