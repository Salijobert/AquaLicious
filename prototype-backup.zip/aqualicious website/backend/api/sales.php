<?php
// backend/api/sales.php  –  Record and query sales
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../config/db.php';

setCORSHeaders();
$user = requireAuth();

$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);

// ── LIST ──────────────────────────────────────────────────────────
if ($method === 'GET') {
    $db      = getDB();
    $search  = $_GET['search'] ?? '';
    $date    = $_GET['date']   ?? '';
    $from    = $_GET['from']   ?? '';
    $to      = $_GET['to']     ?? '';
    $limit   = min((int)($_GET['limit'] ?? 50), 200);
    $offset  = (int)($_GET['offset'] ?? 0);

    $sql = '
        SELECT s.id, s.qty, s.unit_price, s.total, s.customer, s.status,
               DATE(s.sold_at) AS date, TIME(s.sold_at) AS time,
               p.id AS product_id, p.name AS product_name
        FROM sales s JOIN products p ON p.id = s.product_id
        WHERE 1=1';
    $params = [];
    if ($search) { $sql .= ' AND p.name LIKE ?'; $params[] = "%$search%"; }
    if ($date)   { $sql .= ' AND DATE(s.sold_at) = ?'; $params[] = $date; }
    if ($from)   { $sql .= ' AND DATE(s.sold_at) >= ?'; $params[] = $from; }
    if ($to)     { $sql .= ' AND DATE(s.sold_at) <= ?'; $params[] = $to; }
    $sql .= ' ORDER BY s.sold_at DESC LIMIT ? OFFSET ?';
    $params[] = $limit; $params[] = $offset;

    $stmt = $db->prepare($sql); $stmt->execute($params);
    jsonSuccess($stmt->fetchAll());
}

// ── CREATE SALE ───────────────────────────────────────────────────
if ($method === 'POST') {
    $body      = getJsonBody();
    $productId = (int)  ($body['product_id'] ?? 0);
    $qty       = (int)  ($body['qty']        ?? 0);
    $unitPrice = (float)($body['unit_price'] ?? 0);
    $customer  = trim($body['customer'] ?? 'Walk-in');
    if (!$productId || $qty < 1 || $unitPrice <= 0) jsonError('product_id, qty, and unit_price required.');

    $db   = getDB();
    $prod = $db->prepare('SELECT id, name, stock FROM products WHERE id=? AND active=1');
    $prod->execute([$productId]);
    $product = $prod->fetch();
    if (!$product) jsonError('Product not found.', 404);
    if ($product['stock'] < $qty) jsonError("Insufficient stock. Available: {$product['stock']}.");

    // Begin transaction
    $db->beginTransaction();
    try {
        $ins = $db->prepare('INSERT INTO sales (product_id,qty,unit_price,total,customer,created_by) VALUES (?,?,?,?,?,?)');
        $ins->execute([$productId, $qty, $unitPrice, $unitPrice*$qty, $customer, $user['id']]);
        $saleId = (int)$db->lastInsertId();

        // Deduct stock
        $db->prepare('UPDATE products SET stock = stock - ? WHERE id=?')->execute([$qty, $productId]);

        // Log inventory change
        $db->prepare('INSERT INTO inventory_logs (product_id,change_qty,reason,logged_by) VALUES (?,?,?,?)')
           ->execute([$productId, -$qty, "Sale #$saleId", $user['id']]);

        $db->commit();
        jsonSuccess(['sale_id' => $saleId], 'Sale recorded.');
    } catch (Exception $e) {
        $db->rollBack();
        jsonError('Transaction failed: ' . $e->getMessage(), 500);
    }
}

// ── VOID SALE ─────────────────────────────────────────────────────
if ($method === 'DELETE') {
    if (!$id) jsonError('id required.');
    $db   = getDB();
    $sale = $db->prepare('SELECT * FROM sales WHERE id=? AND status="Completed"');
    $sale->execute([$id]);
    $s = $sale->fetch();
    if (!$s) jsonError('Sale not found or already voided.', 404);

    $db->beginTransaction();
    try {
        $db->prepare('UPDATE sales SET status="Void" WHERE id=?')->execute([$id]);
        $db->prepare('UPDATE products SET stock = stock + ? WHERE id=?')->execute([$s['qty'], $s['product_id']]);
        $db->prepare('INSERT INTO inventory_logs (product_id,change_qty,reason,logged_by) VALUES (?,?,?,?)')
           ->execute([$s['product_id'], $s['qty'], "Void Sale #$id", $user['id']]);
        $db->commit();
        jsonSuccess(null, 'Sale voided and stock restored.');
    } catch (Exception $e) {
        $db->rollBack();
        jsonError('Void failed: ' . $e->getMessage(), 500);
    }
}
