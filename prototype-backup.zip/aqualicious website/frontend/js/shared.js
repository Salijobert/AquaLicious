/* shared.js – injects sidebar, topbar, auth guard, toast */

(function () {
  // AUTH GUARD
  const user = sessionStorage.getItem('aq_user');
  if (!user) { window.location.href = '../../index.html'; return; }

  // LOCAL DATE HELPER (avoids UTC off-by-one in PH timezone)
  window.localYMD = function (d) {
    d = d || new Date();
    return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
  };

  // DATA STORE
  window.Store = {
    products()   { return JSON.parse(localStorage.getItem('aq_products')   || '[]'); },
    sales()      { return JSON.parse(localStorage.getItem('aq_sales')      || '[]'); },
    activeSales(){ return this.sales().filter(s => s.status !== 'Voided'); },
    inventory()  { return JSON.parse(localStorage.getItem('aq_inventory')  || '[]'); },
    preorders()  { return JSON.parse(localStorage.getItem('aq_preorders')  || '[]'); },
    savePreorders(d) { localStorage.setItem('aq_preorders', JSON.stringify(d)); if (window.refreshNotifications) refreshNotifications(); },
    saveProducts(d)  { localStorage.setItem('aq_products',  JSON.stringify(d)); },
    saveSales(d)     { localStorage.setItem('aq_sales',     JSON.stringify(d)); },
    saveInventory(d) { localStorage.setItem('aq_inventory', JSON.stringify(d)); },
    nextId(arr)  { return arr.length ? Math.max(...arr.map(x=>x.id||0))+1 : 1; },
    seed() {
      if (!localStorage.getItem('aq_seeded')) {
        const prods = [
          {id:1,name:'Slim Bottle 500ml',   category:'Slim',    price:8,  cost:3,  stock:120, reorder:30},
          {id:2,name:'Round Bottle 500ml',  category:'Round',   price:8,  cost:3,  stock:95,  reorder:30},
          {id:3,name:'Slim Gallon 5L',      category:'Slim',    price:25, cost:10, stock:60,  reorder:20},
          {id:4,name:'Round Gallon 5L',     category:'Round',   price:25, cost:10, stock:14,  reorder:20},
          {id:5,name:'Purified Water 1L',   category:'Purified',price:12, cost:4,  stock:200, reorder:50},
          {id:6,name:'Mineral Water 1.5L',  category:'Mineral', price:18, cost:7,  stock:5,   reorder:25},
        ];
        const sales = [];
        const days  = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
        let sid = 1;
        for (let d = 13; d >= 0; d--) {
          const dt = new Date(); dt.setDate(dt.getDate()-d);
          const count = 3 + Math.floor(Math.random()*5);
          for (let i = 0; i < count; i++) {
            const p = prods[Math.floor(Math.random()*prods.length)];
            const qty = 1 + Math.floor(Math.random()*5);
            sales.push({
              id: sid++, date: localYMD(dt),
              time: `${8+Math.floor(Math.random()*10)}:${String(Math.floor(Math.random()*60)).padStart(2,'0')}`,
              productId: p.id, productName: p.name, qty,
              unitPrice: p.price, total: p.price*qty,
              customer: `Customer ${sid}`, status: 'Completed'
            });
          }
        }
        localStorage.setItem('aq_products',  JSON.stringify(prods));
        localStorage.setItem('aq_sales',     JSON.stringify(sales));
        localStorage.setItem('aq_inventory', JSON.stringify(prods.map(p => ({...p}))));
        localStorage.setItem('aq_seeded', '1');
      }
    }
  };
  Store.seed();
  const _saveProducts = Store.saveProducts;
  Store.saveProducts = function (d) { _saveProducts(d); if (window.refreshNotifications) refreshNotifications(); };

  // SIDEBAR HTML
  const page = window.location.pathname.split('/').pop().replace('.html','');
  const navItems = [
    { id:'dashboard',  label:'Dashboard',    href:'dashboard.html',  icon:'M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z' },
    { id:'products',   label:'Products',     href:'products.html',   icon:'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
      icon2:'M20 3H4v10c0 2.21 1.79 4 4 4h6c2.21 0 4-1.79 4-4v-3h2c1.11 0 2-.89 2-2V5c0-1.11-.89-2-2-2zm0 5h-2V5h2v3zM4 19h16v2H4z' },
    { id:'sales',      label:'View Sales',   href:'sales.html',      icon:'M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.11 0 2-.9 2-2V5c0-1.1-.89-2-2-2zm-7 3c1.93 0 3.5 1.57 3.5 3.5S13.93 13 12 13s-3.5-1.57-3.5-3.5S10.07 6 12 6zm7 13H5v-.23c0-.62.28-1.2.76-1.58C7.47 15.82 9.64 15 12 15s4.53.82 6.24 2.19c.48.38.76.97.76 1.58V19z' },
    { id:'inventory',  label:'Inventory',    href:'inventory.html',  icon:'M20 6h-2.18c.07-.44.18-.88.18-1.35 0-2.58-2.09-4.67-4.67-4.67-1.48 0-2.79.68-3.68 1.74L9 3.06c-.89-1.06-2.2-1.74-3.68-1.74C2.74 1.32.65 3.41.65 6c0 .47.11.91.18 1.35H-0.01c-1.1 0-1.99.9-1.99 2v9c0 1.1.9 2 2 2h20c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-8.5 11.5H5v-6.5h6.5v6.5zm7.5 0H13v-6.5H19v6.5z' },
    { id:'reports',    label:'Reports',      href:'reports.html',    icon:'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z' },
  ];

  const navHTML = navItems.map(n => `
    <a href="${n.href}" class="nav-item ${page===n.id?'active':''}">
      <svg viewBox="0 0 24 24" fill="currentColor"><path d="${n.icon2||n.icon}"/></svg>
      ${n.label}
    </a>`).join('');

  const initial = (user[0]||'A').toUpperCase();

  const sidebarHTML = `
  <aside class="sidebar">
    <div class="sidebar-brand">
      <div class="brand-logo"><svg viewBox="0 0 24 24"><path d="M12 2C8 7 4 10.5 4 14a8 8 0 0016 0c0-3.5-4-7-8-12z"/></svg></div>
      <span class="brand-name">AquaLicious</span>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section">
        <div class="nav-section-label">Main Menu</div>
        ${navHTML}
      </div>
    </nav>
    <div class="sidebar-footer">
      <div class="sidebar-user">
        <div class="user-avatar">${initial}</div>
        <div class="user-info">
          <div class="user-name">${user}</div>
          <div class="user-role">Administrator</div>
        </div>
      </div>
      <button class="btn-logout" onclick="logout()">← Logout</button>
    </div>
  </aside>`;

  // TOPBAR
  const titles = { dashboard:'Dashboard', products:'Manage Products', sales:'Sales Transactions', inventory:'Inventory Monitoring', reports:'Reports & Analytics' };
  const topbarHTML = `
  <header class="topbar">
    <span class="topbar-title">${titles[page]||'Admin Panel'}</span>
    <div class="topbar-right">
      <div class="notif-wrap">
        <button class="notif-btn" id="notifBtn" onclick="toggleNotif(event)" aria-label="Notifications">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/></svg>
          <span class="notif-count" id="notifCount" style="display:none">0</span>
        </button>
        <div class="notif-panel" id="notifPanel">
          <div class="notif-head">Notifications</div>
          <div id="notifList"></div>
        </div>
      </div>
      <span class="topbar-date" id="topbarDate"></span>
      <span class="topbar-badge">Admin</span>
    </div>
  </header>`;

  // TOAST
  const toastHTML = `<div id="toast"></div>`;

  // INJECT
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('.layout').insertAdjacentHTML('afterbegin', sidebarHTML);
    document.querySelector('.main').insertAdjacentHTML('afterbegin', topbarHTML);
    document.body.insertAdjacentHTML('beforeend', toastHTML);
    // Date
    const el = document.getElementById('topbarDate');
    if (el) el.textContent = new Date().toLocaleDateString('en-PH',{weekday:'short',year:'numeric',month:'short',day:'numeric'});
    refreshNotifications();
    // one-time pop-up per login session
    const low = lowStockItems();
    if (low.length && !sessionStorage.getItem('aq_notified')) {
      sessionStorage.setItem('aq_notified','1');
      setTimeout(() => toast(`⚠️ ${low.length} product${low.length>1?'s':''} need restocking`, 4000), 400);
    }
    document.addEventListener('click', e => {
      if (!e.target.closest('.notif-wrap')) document.getElementById('notifPanel')?.classList.remove('open');
    });
  });

  // NOTIFICATIONS (replaces the old Reorder Point alerts)
  function lowStockItems() {
    return Store.products().filter(p => p.stock <= p.reorder);
  }
  window.refreshNotifications = function () {
    const low = lowStockItems();
    const pending = Store.preorders().filter(o => o.status === 'Pending').reverse();
    const badge = document.getElementById('notifCount');
    const list  = document.getElementById('notifList');
    if (!badge || !list) return;
    const total = low.length + pending.length;
    badge.textContent = total;
    badge.style.display = total ? 'flex' : 'none';
    const preHTML = pending.map(o => `
      <a class="notif-item" href="${page==='reports' ? '#preorder' : 'reports.html#preorder'}" onclick="document.getElementById('notifPanel').classList.remove('open')">
        <span class="notif-dot" style="background:var(--blue-bright)"></span>
        <div><strong>🛒 New pre-order: ${o.name}</strong><br/>
        <span>${o.items} × ${o.qty} – ₱${Number(o.total).toLocaleString()} · ${o.date}</span></div>
      </a>`).join('');
    list.innerHTML = preHTML + (low.length ? low.map(p => `
      <a class="notif-item" href="${page==='inventory' ? '#' : 'inventory.html'}">
        <span class="notif-dot ${p.stock===0?'out':''}"></span>
        <div><strong>${p.name}</strong><br/>
        <span>${p.stock===0 ? 'Out of stock' : 'Low stock: only '+p.stock+' left'} – please restock</span></div>
      </a>`).join('') : (pending.length ? '' : '<div class="notif-empty">✅ No new notifications.</div>'));
  };
  window.toggleNotif = function (e) {
    e.stopPropagation();
    document.getElementById('notifPanel').classList.toggle('open');
  };

  window.logout = function () {
    sessionStorage.removeItem('aq_user');
    window.location.href = '../../index.html';
  };

  window.toast = function (msg, ms=2500) {
    const t = document.getElementById('toast');
    t.textContent = msg; t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), ms);
  };

  window.confirm2 = function (msg) { return window.confirm(msg); };
})();
