# AquaLicious Admin System
**Web-Based POS Management System for AquaLicious Water Refilling Station**
*With Sales Management, Inventory Monitoring, and Data Analytics*

---

## 📁 Project Structure

```
aqualicious/
├── index.html                  ← Landing page + Login/Register
├── frontend/
│   ├── css/
│   │   └── shared.css          ← Design system & shared styles
│   ├── js/
│   │   └── shared.js           ← Auth guard, sidebar, data store
│   └── pages/
│       ├── dashboard.html      ← Admin dashboard (stats, charts, ROP)
│       ├── products.html       ← Manage products (Add/Edit/Delete)
│       ├── sales.html          ← Sales transactions + new sale
│       ├── inventory.html      ← Stock levels + ROP alerts + restock
│       └── reports.html        ← Data analytics & revenue reports
└── backend/                    ← PHP + MySQL API (for production)
    ├── config/
    │   └── db.php              ← Database connection
    ├── includes/
    │   └── helpers.php         ← CORS, response, auth helpers
    ├── api/
    │   ├── auth.php            ← Login / Logout / Register
    │   ├── products.php        ← Products CRUD API
    │   ├── sales.php           ← Sales recording & voiding API
    │   ├── inventory.php       ← Stock management API
    │   └── reports.php         ← Analytics & reports API
    └── schema.sql              ← MySQL database schema
```

---

## 🚀 Quick Start (Frontend Only — No Server Required)

1. Open `index.html` in any modern browser (Chrome, Edge, Firefox)
2. **Default login credentials:**
   - Username: `admin`
   - Password: `admin123`
3. The frontend uses `localStorage` to store all data — no backend needed to demo.

---

## ⚙️ Full Stack Setup (PHP + MySQL)

### Requirements
- PHP 8.0+ with PDO extension enabled
- MySQL 8.0+
- Apache / Nginx web server (or XAMPP / WAMP for local dev)

### Steps

**1. Create the database**
```bash
mysql -u root -p < backend/schema.sql
```

**2. Configure database connection**
Edit `backend/config/db.php`:
```php
define('DB_HOST',     'localhost');
define('DB_USER',     'your_user');
define('DB_PASSWORD', 'your_password');
define('DB_NAME',     'aqualicious_db');
```

**3. Update frontend API base URL**
In `frontend/js/shared.js`, set:
```js
const API_BASE = 'http://localhost/aqualicious/backend/api';
```

**4. Deploy to web server**
Copy the entire `aqualicious/` folder to your web server root (e.g., `htdocs/` for XAMPP).

**5. Access the system**
Open: `http://localhost/aqualicious/index.html`

---

## 🔐 Default Admin Credentials
| Field    | Value      |
|----------|------------|
| Username | `admin`    |
| Password | `admin123` |

> ⚠️ Change these credentials before deploying to production!

---

## 📊 Features Based on Flowchart

### Admin Web Application Flow
1. **Login** → Admin Dashboard
2. **Select Action** → Choose from:
   - **Manage Products** → Add / Edit / Delete Product → Save Changes
   - **View Sales** → Display Transactions → Filter / Search Records
   - **Inventory Monitoring** → View Stock Levels → Check ROP Alerts
   - **Reports & Analytics** → Generate Reports → View Trends
3. **Data Retrieved from MySQL Database**
4. **Logout** → End

---

## 🛠 Technologies Used
- **Frontend:** HTML5, CSS3 (custom design system), Vanilla JavaScript
- **Backend:** PHP 8 (REST API)
- **Database:** MySQL 8 with PDO
- **Data Storage (demo):** localStorage (browser)
- **Fonts:** Poppins + Playfair Display (Google Fonts)

---

## 📋 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth.php?action=login` | Admin login |
| POST | `/api/auth.php?action=logout` | Logout |
| POST | `/api/auth.php?action=register` | Register new admin |
| GET | `/api/products.php` | List all products |
| POST | `/api/products.php` | Create product |
| PUT | `/api/products.php?id=N` | Update product |
| DELETE | `/api/products.php?id=N` | Delete product |
| GET | `/api/sales.php` | List sales |
| POST | `/api/sales.php` | Record new sale |
| DELETE | `/api/sales.php?id=N` | Void a sale |
| GET | `/api/inventory.php?action=list` | Stock levels |
| GET | `/api/inventory.php?action=rop` | ROP alerts |
| POST | `/api/inventory.php?action=restock` | Restock product |
| GET | `/api/reports.php?action=summary` | Summary analytics |
| GET | `/api/reports.php?action=daily` | Daily sales trend |
| GET | `/api/reports.php?action=monthly` | Total revenue per month |
| GET | `/api/reports.php?action=top_products` | Top products |
| GET | `/api/reports.php?action=categories` | Category breakdown |

---

## 👥 Developed For
**AquaLicious Water Refilling Station**
*City College of Angeles – Bachelor of Science in Computer Science*
*March 2026*
